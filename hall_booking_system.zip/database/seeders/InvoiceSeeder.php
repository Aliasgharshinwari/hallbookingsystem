<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class InvoiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('invoice')->insert([
        //     [
        //         'id' => 1,
        //         'booking_id' => 1,
        //         'payment_paid' => 5000,
        //         'date_paid' => '2024-06-01',
        //     ],
        //     [
        //         'id' => 2,
        //         'booking_id' => 1,
        //         'payment_paid' => 10000,
        //         'date_paid' => '2024-06-10',
        //     ],
        // ]);
    }
}
