

<?php $__env->startSection('content'); ?>
    <head>
        <title>Customers</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    </head>

    <div class="container">
        <h2>Add Department</h2>
        <form action="<?php echo e(route('customers.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="customer_name">Name:</label>
                <input type="text" class="form-control" id="customer_name" name="customer_name">
            </div>
            <button type="submit" class="btn btn-primary">Add Customer</button>
        </form>

        <h2>Customers List</h2>
        <table class="table table-hover table-responsive">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
            </tr>
            </thead>
            <tbody>
            <!-- <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($customer->customer_id); ?></td>
                    <td><?php echo e($customer->customer_name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\hall_booking_system\resources\views/customers.blade.php ENDPATH**/ ?>