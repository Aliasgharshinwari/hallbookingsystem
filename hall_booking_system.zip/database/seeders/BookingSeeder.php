<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BookingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('booking')->insert([
        //     [
        //         'id' => 1,
        //         'customer_id' => 1,
        //         'hall_id' => 1,
        //         'booking_start_time' => '2024-06-01',
        //         'booking_end_time' => '2024-06-02',
        //     ],
        //     [  
        //          'id' => 2,
        //         'customer_id' => 2,
        //         'hall_id' => 2,
        //         'booking_start_time' => '2024-06-01',
        //         'booking_end_time' => '2024-06-02',
        //     ],
        // ]);
    }
    
    
        
    
    
    
    
    


}
